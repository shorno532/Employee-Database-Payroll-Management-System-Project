<?php  include 'core/initForMainLogPage.php'; ?>

<?php  include 'includes/mainPageHead.php'; ?>

<body>
<div class="container_currency">

 </div>
 
  <div id="containerMainLogin">
 <?php include 'includes/mianPageLogin.php'; ?>
 
</div>

</body>
</html>