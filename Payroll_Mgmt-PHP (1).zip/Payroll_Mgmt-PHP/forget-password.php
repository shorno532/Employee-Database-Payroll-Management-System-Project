<?php  include 'core/initForMainLogPage.php'; ?>

<?php  include 'includes/mainPageHead.php'; ?>

<body>
 <div id="containerMainLogin">
 <?php include 'includes/forgot-password-form.php'; ?>
</div>
 

</body>
</html>