<?php  include 'core/initForMainLogPage.php'; ?>

<?php  include 'includes/mainPageHead.php'; ?>

<body>
 <div id="containerMainLogin">
 <?php include 'includes/activate-form.php'; ?>
</div>
 

</body>
</html>