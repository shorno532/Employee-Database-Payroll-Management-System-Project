 <footer>
<p> &copy;Copyright &nbsp; Salary Payroll Management System Project.</p>
 </footer>