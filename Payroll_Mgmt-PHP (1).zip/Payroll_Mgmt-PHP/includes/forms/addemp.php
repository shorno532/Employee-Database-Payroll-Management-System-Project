

<form action="" method="post">
  <table cellpadding="0" cellspacing="0">
   <tr><td>Company Name: </td><td><input type="text" name="compName"></td></tr>
   <tr><td>Address: </td><td><input type="text" name="compAddress"></td></tr>
   <tr><td>Registration No: </td><td><input type="text" name="compReg"></td></tr>
   <tr><td>Number Of Hours </td><td><input type="text" name="compHours"></td></tr>
   <tr><td>Date Formed: </td><td><input type="text" name="compFormed"></td></tr>
   <tr><td>Number Of Emp: </td><td><input type="text" name="compEmp"></td></tr>
   <tr><td> </td><td><input type="submit" value="Add"></td></tr>
</table>
</form>